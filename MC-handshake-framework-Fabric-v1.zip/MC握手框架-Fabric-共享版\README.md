# MC 握手框架 · Fabric 版（共享版）

给 mineflayer 系机器人接入 **Fabric** 模组服：原版协议客户端会卡在 Fabric 的登录期
channel（early_registration / 自定义握手）和 registry 同步上，这里补的就是这一层。

## 内容

| 文件 | 作用 |
|---|---|
| src/fabric.mjs | Fabric 登录期 channel 应答（early_registration、自定义握手） |
| src/mod-registry.mjs | 接住 `fabric:registry/sync/direct` 注入方块/物品/实体；state 表注入 + shapes 兜底 |
| extensions/mod-knowledge.mjs | 模组名/ID 辅助表 |
| utopia/ | **乌托邦（1.20.1 Fabric）适配数据**：state 表、注册表快照、模组清单、owo 握手哈希与应答 |

## 接法

1. `src/*.mjs` 放进机器人项目的 src/；
2. 连接前 `injectRegistries(bot, registries)`、`installStateTable(bot, table)`；
3. `table` 用 `loadStateTable()` 读 `utopia/block_states.txt`（每行 `stateId|namespace:block`）；
4. 握手通道名与哈希见 `utopia/fabric-handshake.json` 与 `fabric-responses.json`。

## 已知限制

- `owo:handshake` 要三个通道哈希，必须和服务端完全一致，错一个就 `mismatched hashes`；
- 方块 state id 不在网络包里，`block_states.txt` 是从服务端注册表 + 模组 jar 的 blockstates 反推的，**换整合包必须重导**；
- state 表里每个方块对象必须带 `shapes` 数组，缺了会让 prismarine-physics 抛
  `TypeError: block.shapes is not iterable`，直接崩宿主进程。`mod-registry.mjs` 已做兜底。

## 隐私

不含账号、密码、token、API key、cookie、服务器地址与个人昵称。
