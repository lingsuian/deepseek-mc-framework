// -*- coding: utf-8 -*-
/**
 * whale_craft / fabric.mjs —— Fabric 模组服 login 阶段握手兼容层
 * ---------------------------------------------------------------------------
 * 背景：原版协议客户端（mineflayer）进 Fabric 模组服时，服务端的模组会在
 * login 阶段发 `login_plugin_request`（Login Plugin Request），等客户端回答。
 * 不回包的客户端会被踢，典型如 owo-lib：
 *
 *   oωo > handshake failure
 *   client did not respond to channel query
 *
 * 本模块对每个 request 自动应答，让机器人能穿过这一层。已知通道：
 *   · owo:handshake                         —— 必答，格式是三个 map<Identifier,int>
 *   · fabric-networking-api-v1:early_registration —— 空
 *   · fabric:custom_ingredient_sync         —— 空
 *   · forgeconfigapiport:sync_configs       —— 空
 *   · forgeconfigapiport:modded_connection  —— 空
 *   · framework:handshake                   —— 空（服务端不强制时够用）
 *   · toms_storage:config                   —— 空
 *
 * owo 的应答是**三张哈希表**（required channels / particle controllers / optional
 * channels），哈希由服务端模组代码决定，写死在 `$DSH_HOME/whale_craft/fabric.json`
 * 的 `owo` 字段里。没配置时回三张空表：服务端会明确报出缺哪些 channel，日志里
 * 能看到，方便照单补 hash。
 * ---------------------------------------------------------------------------
 */

import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { homedir } from 'node:os'
import { createRequire } from 'node:module'

/** 锚到 mineflayer 自己的依赖树，保证和它用的是同一份 minecraft-data */
const requireFromMineflayer = (() => {
  try { return createRequire(createRequire(import.meta.url).resolve('mineflayer')) } catch { return createRequire(import.meta.url) }
})()

/**
 * 模组服协议兼容：必须在 createBot **之前**调用。
 *
 * 模组服在 play 阶段发 declare_recipes，里面的 slot NBT 常常越过
 * minecraft-data 的解析边界，protodef 抛 ReadError 后整条流卡死
 * （现象：login 全过、包收了一串，然后一包不再来，bot 永远 spawn 不了）。
 * 把 declare_recipes 改成 restBuffer 就通了，只丢配方书，不影响其它。
 */
export function installModdedClientCompat () {
  const targets = ['1.20.1', '1.20', '1.20.2', '1.20.3', '1.20.4', '1.20.5', '1.20.6']
  let patched = 0
  try {
    const mcd = requireFromMineflayer('minecraft-data')
    for (const v of targets) {
      try {
        const data = mcd(v)
        const fields = data?.protocol?.play?.toClient?.types?.packet?.[1]?.[1]?.type?.[1]?.fields
        if (fields && fields.declare_recipes && fields.declare_recipes !== 'restBuffer') {
          fields.declare_recipes = 'restBuffer'
          patched++
        }
      } catch { /* 该版本没有这份协议数据就算了 */ }
    }
  } catch { /* minecraft-data 解析不到就算了 */ }
  return patched
}

const DSH_HOME = process.env.DSH_HOME || join(homedir(), '.dsh')
const CONFIG_PATH = join(DSH_HOME, 'whale_craft', 'fabric.json')
const RESPONSES_PATH = join(DSH_HOME, 'whale_craft', 'fabric-responses.json')

/* ───────────── 二进制小工具（Minecraft VarInt / String）───────────── */

function writeVarInt (n) {
  const out = []
  let v = n >>> 0
  do {
    let b = v & 0x7f
    v >>>= 7
    if (v) b |= 0x80
    out.push(b)
  } while (v)
  return Buffer.from(out)
}

function writeString (s) {
  const b = Buffer.from(String(s), 'utf8')
  return Buffer.concat([writeVarInt(b.length), b])
}

/** map<Identifier, Integer>：VarInt(size) + size×(String(key) + VarInt(value)) */
function writeHashMap (entries) {
  const list = Array.isArray(entries) ? entries : Object.entries(entries || {})
  const parts = [writeVarInt(list.length)]
  for (const [k, v] of list) parts.push(writeString(k), writeVarInt(v | 0))
  return Buffer.concat(parts)
}

/* ───────────── 配置 ───────────── */

function loadConfig () {
  const fallback = { owo: null }
  try {
    if (!existsSync(CONFIG_PATH)) return fallback
    const raw = JSON.parse(readFileSync(CONFIG_PATH, 'utf8'))
    return {
      owo: raw?.owo || null,
      // 允许逐通道覆盖：{ "channel": "hex:..." }，值为原始 payload（hex 字符串）
      channels: raw?.channels || null,
    }
  } catch {
    return fallback
  }
}

/** 从真客户端抓下来的逐通道响应（按 channel 索引，忽略 messageId 顺序） */
function loadCapturedResponses () {
  try {
    if (!existsSync(RESPONSES_PATH)) return null
    const raw = JSON.parse(readFileSync(RESPONSES_PATH, 'utf8'))
    const byChannel = {}
    for (const v of Object.values(raw)) {
      if (v && typeof v.channel === 'string' && typeof v.hex === 'string') {
        byChannel[v.channel] = Buffer.from(v.hex, 'hex')
      }
    }
    return Object.keys(byChannel).length ? byChannel : null
  } catch {
    return null
  }
}

/** 由 { channel: hash } + { controller: hash } 生成 owo handshake 响应 */
function buildOwoPayload (owoCfg) {
  if (!owoCfg || (!owoCfg.channels && !owoCfg.controllers)) {
    // 空表：服务端会报 "client is missing channels: ..."，日志里能拿到清单
    return Buffer.concat([writeHashMap([]), writeHashMap([]), writeHashMap([])])
  }
  const channels = writeHashMap(owoCfg.channels || {})
  const controllers = writeHashMap(owoCfg.controllers || {})
  const optional = writeHashMap(owoCfg.optional || {})
  return Buffer.concat([channels, controllers, optional])
}

/* ───────────── 应答策略 ───────────── */

function responseFor (channel, cfg, replay) {
  // 真客户端抓下来的原样响应优先（owo 和 fabric 的格式都在里面）
  if (replay && replay[channel]) return replay[channel]
  // 逐通道 hex 覆盖
  const override = cfg.channels?.[channel]
  if (typeof override === 'string') {
    const hex = override.startsWith('hex:') ? override.slice(4) : override
    return Buffer.from(hex.replace(/[^0-9a-f]/gi, ''), 'hex')
  }
  if (channel === 'owo:handshake') return buildOwoPayload(cfg.owo)
  // 其余模组通道一律空 payload —— 它们只校验"客户端有没有回"
  return Buffer.alloc(0)
}

/* ───────────── 挂载 ───────────── */

/**
 * 给一个 mineflayer bot 挂 login 阶段握手处理。
 * 必须在 createBot 之后、TCP 连接建立之前调用（createBot 是异步连接的，立刻挂即可）。
 *
 * @param {object} bot      mineflayer bot
 * @param {object} [opts]
 * @param {(msg:string)=>void} [opts.log] 日志回调
 * @returns {{detach:()=>void, seen:string[]}}
 */
export function attachFabricHandshake (bot, opts = {}) {
  const log = opts.log || (() => {})
  const cfg = loadConfig()
  const replay = loadCapturedResponses()
  const seen = []
  const client = bot?._client
  if (!client) return { detach () {}, seen }

  // minecraft-protocol 自带一个 login_plugin_request 监听器，会回 successful=false。
  // 不摘掉的话每个 request 被回两次，服务端第二遍就报
  // multiplayer.disconnect.unexpected_query_response。
  try { client.removeAllListeners('login_plugin_request') } catch { /* ignore */ }

  const onPacket = (data, meta) => {
    if (!meta || meta.name !== 'login_plugin_request') return
    const channel = data?.channel
    if (!channel) return
    // Forge 的 FML 握手交给 forge.mjs 处理，这里不能抢着回空包
    if (channel.startsWith('fml:')) return
    seen.push(channel)
    let payload
    try {
      payload = responseFor(channel, cfg, replay)
    } catch (e) {
      log(`Fabric 握手：构造 ${channel} 响应失败 → 回空（${e.message}）`)
      payload = Buffer.alloc(0)
    }
    try {
      client.write('login_plugin_response', {
        messageId: data.messageId,
        successful: true,
        data: payload,
      })
      log(`Fabric 握手：${channel} → 已应答（${payload.length}B）`)
    } catch (e) {
      log(`Fabric 握手：${channel} 应答失败（${e.message}）`)
    }
  }

  client.on('packet', onPacket)
  log('Fabric 握手兼容层已挂载')

  return {
    seen,
    detach () {
      try { client.off('packet', onPacket) } catch { /* ignore */ }
    },
  }
}

export { CONFIG_PATH as FABRIC_CONFIG_PATH, buildOwoPayload, writeHashMap, writeString, writeVarInt }
