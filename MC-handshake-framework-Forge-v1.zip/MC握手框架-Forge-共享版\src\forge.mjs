// -*- coding: utf-8 -*-
/**
 * forge.mjs —— 让原版协议客户端（mineflayer）过 Forge 服的 FML3 登录握手
 *
 * Forge 1.13+ 在 login 阶段用 `fml:loginwrapper` / `fml:handshake` 跑一整套
 * FML 握手：服务端发 ModList / ServerRegistry / ConfigurationData / ModData，
 * 客户端必须按格式回 ModListReply / Acknowledgement，不回就被判「不兼容客户端」。
 *
 * 这里移植 PrismarineJS/node-minecraft-protocol-forge 的 FML3 实现（master，
 * 未发布到 npm），改成 ES module 并挂到 mineflayer 的 Client 上。
 *
 * 关键点：
 *   · 不需要真的知道客户端装了哪些模组 —— modNames/channels/registries 直接
 *     反射服务端发来的那张表（服务器要的是"你和我一样"，不是"你真装了"）。
 *   · 必须摘掉 minecraft-protocol 默认的 login_plugin_request 监听器，它会给
 *     每个请求回空包，服务端收到空包直接断（和 Fabric 那次同一个坑）。
 *   · 只在 Forge 服生效；Fabric 服没有 `fml:` 前缀的包，挂上无副作用。
 *
 * 边界：这只保证"进得去"。Forge 的注册表同步（ServerRegistry 的实际内容）
 *       只回 Ack 不改本地 registry —— 方块名/物品 id 的映射仍需要另外导一次，
 *       同 Fabric 那边的 state 表方案。
 */
import { createRequire } from 'node:module'
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const HERE = dirname(fileURLToPath(import.meta.url))
const requireFromMineflayer = (() => {
  try { return createRequire(createRequire(import.meta.url).resolve('mineflayer')) } catch { return createRequire(import.meta.url) }
})()

const FML_CHANNELS = {
  LOGINWRAPPER: 'fml:loginwrapper',
  HANDSHAKE: 'fml:handshake',
}

let proto = null
function getProto () {
  if (proto) return proto
  const { ProtoDef } = requireFromMineflayer('protodef')
  proto = new ProtoDef(false)
  proto.addType('string', ['pstring', { countType: 'varint' }])
  proto.addTypes({
    restBuffer: [
      (buffer, offset) => ({ value: buffer.slice(offset), size: buffer.length - offset }),
      (value, buffer, offset) => { value.copy(buffer, offset); return offset + value.length },
      (value) => value.length,
    ],
  })
  const data = JSON.parse(readFileSync(join(HERE, 'data', 'fml3.json'), 'utf8'))
  proto.addProtocol(data, ['fml3'])
  return proto
}

function ackPayload (p) {
  return p.createPacketBuffer('fml_loginwrapper', {
    channel: FML_CHANNELS.HANDSHAKE,
    data: p.createPacketBuffer('fml_handshake', {
      discriminator: 'Acknowledgement',
      data: {},
    }),
  })
}

/**
 * 挂到 bot 上：收到 fml:loginwrapper 请求就按 FML3 握手格式应答。
 * @param {object} bot
 * @param {{log?:Function, forgeMods?:string[], channels?:object, registries?:object}} [options]
 */
export function attachForgeHandshake (bot, options = {}) {
  const client = bot?._client
  if (!client) return { detach () {}, get active () { return false } }

  const log = options.log || (() => {})
  const p = getProto()

  // 告诉 minecraft-protocol 的 autoVersion：我们支持 FML3
  try { client.tagHost = '\0FML3\0' } catch { /* ignore */ }

  try {
    client.registerChannel('fml:loginwrapper', p.types.fml_loginwrapper, false)
  } catch (e) {
    log('Forge 握手：注册 fml:loginwrapper 失败（' + e.message + '）')
    return { detach () {}, get active () { return false } }
  }

  // 摘掉默认监听器：它回空包会让服务端直接断
  try {
    const nmplistener = client.listeners('login_plugin_request').find((fn) => fn.name === 'onLoginPluginRequest')
    if (nmplistener) client.removeListener('login_plugin_request', nmplistener)
  } catch { /* ignore */ }

  let handled = 0

  const onPlugin = (data) => {
    if (data.channel !== FML_CHANNELS.LOGINWRAPPER) return
    try {
      const { data: loginwrapper } = p.parsePacketBuffer('fml_loginwrapper', data.data)
      if (loginwrapper.channel !== FML_CHANNELS.HANDSHAKE) {
        // 其他 login 通道一律 Ack，不然服务端会等
        client.write('login_plugin_response', { messageId: data.messageId, data: ackPayload(p) })
        return
      }
      const { data: handshake } = p.parsePacketBuffer('fml_handshake', loginwrapper.data)
      let reply = null

      switch (handshake.discriminator) {
        case 'ModList': {
          const modlist = handshake.data
          const modNames = options.forgeMods || modlist.modNames || []
          const channels = []
          if (options.channels) {
            for (const [name, marker] of Object.entries(options.channels)) channels.push({ name, marker })
          } else {
            for (const { name, marker } of (modlist.channels || [])) {
              if (marker !== 'FML3') channels.push({ name, marker })
            }
          }
          const registries = []
          if (options.registries) {
            for (const [name, marker] of Object.entries(options.registries)) registries.push({ name, marker })
          } else {
            for (const { name } of (modlist.registries || [])) registries.push({ name, marker: '1.0' })
          }
          const modlistreplypacket = p.createPacketBuffer('fml_handshake', {
            discriminator: 'ModListReply',
            data: { modNames, channels, registries },
          })
          reply = p.createPacketBuffer('fml_loginwrapper', {
            channel: FML_CHANNELS.HANDSHAKE,
            data: modlistreplypacket,
          })
          log(`Forge 握手：ModList → ModListReply（${modNames.length} 个模组、${channels.length} 个通道、${registries.length} 个注册表）`)
          break
        }
        case 'ServerRegistry':
        case 'ConfigurationData':
        case 'ModData':
        case 'ChannelMismatchData': {
          reply = ackPayload(p)
          log(`Forge 握手：${handshake.discriminator} → Acknowledgement`)
          break
        }
        case 'ModListReply':
        case 'Acknowledgement':
          // 服务端不该发这两个
          break
        default:
          log(`Forge 握手：未知 discriminator "${handshake.discriminator}"，回 Ack 兜底`)
          reply = ackPayload(p)
          break
      }

      if (reply) {
        client.write('login_plugin_response', { messageId: data.messageId, data: reply })
        handled++
      }
    } catch (e) {
      log('Forge 握手解析失败：' + e.message)
      // 兜底：回一个空 ack，至少不卡住
      try { client.write('login_plugin_response', { messageId: data.messageId, data: ackPayload(p) }) } catch { /* ignore */ }
    }
  }

  client.on('login_plugin_request', onPlugin)
  log('Forge 握手兼容层已挂载（FML3）')

  return {
    detach () {
      try { client.removeListener('login_plugin_request', onPlugin) } catch { /* ignore */ }
    },
    get active () { return true },
    get handled () { return handled },
  }
}
