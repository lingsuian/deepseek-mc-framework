# MC 握手框架 · Forge 版（共享版）

给 mineflayer 系机器人接入 **Forge（FML3，1.18+）** 模组服。
原版协议客户端在登录阶段发不出 FML3 握手，服务端会直接 reset，这里补的就是这一层。

## 内容

| 文件 | 作用 |
|---|---|
| src/forge.mjs | Forge FML3 握手（fmlNetworkVersion 3） |
| src/data/fml3.json | FML3 握手静态数据 |
| src/mod-registry.mjs | state 表注入 + shapes 兜底（Forge 端自定义方块同样需要 state 映射） |
| extensions/mod-knowledge.mjs | 模组名/ID 辅助表 |

## 接法

1. `src/*.mjs` 放进机器人项目的 src/；
2. 连接时按 `forge.mjs` 里的通道名应答 FML3 握手（数据来自 `src/data/fml3.json`）；
3. 进入游戏后 `installStateTable(bot, table)` 注入方块 state 表（表需自行从整合包反推）。

## 已知限制

- FML3 握手要和服务端的 Forge 大版本对齐，换版本得重做；
- Forge 服通常还带 mod list 校验，缺模块会被拒；
- 方块 state id 不在网络包里，需从整合包 jar 的 blockstates 反推；
- state 表里每个方块必须带 `shapes` 数组，缺了会崩宿主（`mod-registry.mjs` 已兜底）。

## 隐私

不含账号、密码、token、API key、cookie、服务器地址与个人昵称。
