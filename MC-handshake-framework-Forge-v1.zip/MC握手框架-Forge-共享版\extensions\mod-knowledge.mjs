// -*- coding: utf-8 -*-
/**
 * mod-knowledge.mjs —— 让MC 机器人知道自己在一个什么模组服上
 *
 * 两个工具：
 *   mc_mods        查服务器装了哪些模组（按关键字/命名空间），以及某个模组加了什么物品和方块
 *   mc_mod_guide   生成一段「我在玩什么」的简报，可直接当上下文用
 *
 * 数据来源：
 *   $DSH_HOME/whale_craft/mods.json              模组清单（从服务器 mods 目录提取）
 *   $DSH_HOME/whale_craft/registry-snapshot.json 服务端注册表快照（连接时自动抓）
 */
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { homedir } from 'node:os'

const DSH_HOME = process.env.DSH_HOME || join(homedir(), '.dsh')
const MODS_PATH = join(DSH_HOME, 'whale_craft', 'mods.json')
const SNAP_PATH = join(DSH_HOME, 'whale_craft', 'registry-snapshot.json')
const GUIDE_PATH = join(DSH_HOME, 'whale_craft', 'server-guide.md')

let modsCache = null
let snapCache = null

function loadMods () {
  if (modsCache) return modsCache
  try {
    if (!existsSync(MODS_PATH)) return { count: 0, mods: [], missing: true }
    modsCache = JSON.parse(readFileSync(MODS_PATH, 'utf8'))
    return modsCache
  } catch {
    return { count: 0, mods: [], missing: true }
  }
}

function loadSnap () {
  if (snapCache) return snapCache
  try {
    if (!existsSync(SNAP_PATH)) return null
    snapCache = JSON.parse(readFileSync(SNAP_PATH, 'utf8'))
    return snapCache
  } catch {
    return null
  }
}

/** 某命名空间下的物品和方块 */
function namespaceEntries (ns) {
  const snap = loadSnap()
  if (!snap) return null
  const items = snap.registries['minecraft:item'] || {}
  const blocks = snap.registries['minecraft:block'] || {}
  const ents = snap.registries['minecraft:entity_type'] || {}
  const pick = (map) => Object.keys(map).filter((k) => k.startsWith(ns + ':')).map((k) => k.slice(ns.length + 1))
  return { items: pick(items), blocks: pick(blocks), entities: pick(ents) }
}

/** 把模组清单按用途粗分，给一段能直接读的简报 */
function buildGuide (limit = 40) {
  const data = loadMods()
  if (!data.mods?.length) return '# 模组清单\n\n还没抓过这个服的模组清单。'
  const groups = {
    '内容/世界': /dungeon|cell|nether|end|biome|dimension|structure|world|terrain|seasons|nature|animal|mob|creature|boss/i,
    '战斗/装备': /combat|weapon|armor|trinket|curio|spell|magic|enchant|artifact|equipment/i,
    '建造/装饰': /building|furniture|decor|roof|bridge|fence|window|painting|chisel|blockus|macaw/i,
    '任务/进度': /quest|advancement|team|ftb/i,
    '存储/物流': /storage|chest|inventory|pipe|logistic|toms|backpack/i,
    '界面/信息': /jei|rei|wthit|jade|map|xero|minimap|tooltip|hud|info/i,
    '性能/底层': /sodium|lithium|ferrite|krypton|indium|modernfix|optimiz|connector|fabric.api|mixin/i,
  }
  const lines = ['# 这个服在玩什么', '']
  lines.push(`服务器：${data.server || '未知'}｜模组 ${data.count} 个。`, '')
  const used = new Set()
  for (const [label, re] of Object.entries(groups)) {
    const hits = data.mods.filter((m) => re.test(m.id) || re.test(m.name) || re.test(m.description || ''))
    if (!hits.length) continue
    lines.push(`## ${label}`)
    for (const m of hits.slice(0, limit)) {
      used.add(m.id)
      const desc = (m.description || '').replace(/\s+/g, ' ').slice(0, 110)
      lines.push(`- **${m.name}**（${m.id}）${desc ? '：' + desc : ''}`)
    }
    lines.push('')
  }
  const rest = data.mods.filter((m) => !used.has(m.id))
  if (rest.length) {
    lines.push(`## 其它（${rest.length} 个）`)
    lines.push(rest.slice(0, 60).map((m) => m.id).join(', '))
    lines.push('')
  }
  lines.push('## 怎么用')
  lines.push('- 手上/箱子里不认识的东西，先看物品名（已是模组真名），再决定要不要用。')
  lines.push('- 需要具体用法时查 `mc_mods`（带 query），或者联网搜「模组名 + 物品名 + 怎么用」。')
  lines.push('- 别乱点/乱丢不认识的物品，有些模组物品会消耗或绑定。')
  return lines.join('\n')
}

export const name = 'mod-knowledge'

export async function apply ({ ctx, asTool, logLine }) {
  const data = loadMods()
  logLine(`模组知识扩展已加载（模组 ${data.count} 个${data.missing ? '，清单未生成' : ''}）`)

  ctx.tools.register(asTool({
    name: 'mc_mods',
    description: '查这个服务器装了哪些模组。可按关键字搜模组，也可以给命名空间列出它加了哪些物品/方块/实体。',
    parameters: {
      query: { type: 'string', description: '关键字（模组 id、名字或描述里的一段）；留空返回总数和前 40 个' },
      namespace: { type: 'string', description: '模组命名空间，比如 minecells；给了就以它为准列物品/方块' },
    },
    output: {
      schema: { type: 'object', properties: {}, additionalProperties: true },
      render: (args, value) => [{ type: 'text', text: JSON.stringify(value, null, 1) }],
    },
    async execute (args) {
      const q = String(args?.query || '').trim().toLowerCase()
      const ns = String(args?.namespace || '').trim().toLowerCase()
      const all = loadMods().mods || []

      if (ns) {
        const mod = all.find((m) => m.id?.toLowerCase() === ns)
        const entries = namespaceEntries(ns)
        return {
          namespace: ns,
          mod: mod ? { id: mod.id, name: mod.name, version: mod.version, description: mod.description } : null,
          items: entries?.items?.slice(0, 200) || [],
          blocks: entries?.blocks?.slice(0, 200) || [],
          entities: entries?.entities?.slice(0, 100) || [],
          counts: entries ? { items: entries.items.length, blocks: entries.blocks.length, entities: entries.entities.length } : null,
          note: entries ? null : '还没有连接过这个服务器，拿不到注册表快照',
        }
      }

      let hits = all
      if (q) {
        hits = all.filter((m) =>
          String(m.id).toLowerCase().includes(q) ||
          String(m.name).toLowerCase().includes(q) ||
          String(m.description || '').toLowerCase().includes(q))
      }
      return {
        total: all.length,
        matched: hits.length,
        mods: hits.slice(0, 60).map((m) => ({ id: m.id, name: m.name, version: m.version, description: (m.description || '').slice(0, 160) })),
        hint: q ? null : '给 query 可以按关键字搜；给 namespace 可以列某个模组的物品和方块',
      }
    },
  }))

  ctx.tools.register(asTool({
    name: 'mc_mod_guide',
    description: '生成一段「我在玩什么模组服」的简报，按建造/战斗/内容/界面分组列模组和解法。',
    parameters: {},
    output: {
      schema: { type: 'object', properties: {}, additionalProperties: true },
      render: (args, value) => [{ type: 'text', text: value?.guide || '' }],
    },
    async execute () {
      const guide = buildGuide()
      try { writeFileSync(GUIDE_PATH, guide) } catch { /* ignore */ }
      return { guide, savedTo: GUIDE_PATH }
    },
  }))
}
