// -*- coding: utf-8 -*-
/**
 * mod-registry.mjs —— 把服务端的注册表灌进 mineflayer
 * ---------------------------------------------------------------------------
 * Fabric 模组服会在 play 阶段用 `fabric:registry/sync/direct` 把整张注册表
 * （方块 / 物品 / 实体 / 生物群系…）推给客户端，1MB 分片，最后发一个空包。
 * 原版协议客户端（mineflayer）收到就丢了，于是：
 *   · 模组实体 → name='unknown'
 *   · 模组物品 → 物品栏里只有数字 id
 *   · 模组方块 → 地图上是未知块
 *
 * 这里把那包接住、解析、注入 registry。
 *
 * 能精确做的：
 *   · 实体：spawn_entity 的 type 就是注册表顺序 id → 名字/displayName/type
 *   · 物品：window_items 的 itemId 就是注册表顺序 id → 名字
 *   · 方块名：blocksByName 补全
 *
 * 做不到的（网络包里没有）：
 *   · 方块的 state id 映射。state id 是「按注册顺序把每个方块的所有状态连续
 *     编号」，每个方块有几种状态由模组 Java 代码的 StateManager 决定，
 *     不在任何网络包里。客户端能对是因为它本地装了同样的模组。
 *     这里只能把未知 state id 兜底成占位块，避免 blockAt 返回 undefined。
 * ---------------------------------------------------------------------------
 */
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { homedir } from 'node:os'

const DSH_HOME = process.env.DSH_HOME || join(homedir(), '.dsh')
export const SNAPSHOT_PATH = join(DSH_HOME, 'whale_craft', 'registry-snapshot.json')
export const STATE_TABLE_PATH = join(DSH_HOME, 'whale_craft', 'block_states.txt')
const CHANNEL = 'fabric:registry/sync/direct'

/* ───────────── 解析 ───────────── */

function parseRegistrySync (buf) {
  let off = 0
  const rv = () => {
    let r = 0; let s = 0; let b
    do { b = buf[off++]; r |= (b & 0x7f) << s; s += 7 } while (b & 0x80)
    return r | 0
  }
  const rs = () => {
    const n = rv()
    const s = buf.subarray(off, off + n).toString('utf8')
    off += n
    return s
  }
  const unopt = (ns) => (ns === '' ? 'minecraft' : ns)

  const regGroups = rv()
  const registries = new Map()
  for (let i = 0; i < regGroups; i++) {
    const regNs = unopt(rs())
    const regCount = rv()
    for (let j = 0; j < regCount; j++) {
      const regPath = rs()
      const idMap = new Map()
      const nsGroups = rv()
      let last = 0
      for (let k = 0; k < nsGroups; k++) {
        const idNs = unopt(rs())
        const bulks = rv()
        for (let b = 0; b < bulks; b++) {
          const diff = rv()
          const size = rv()
          const first = last + diff
          for (let x = 0; x < size; x++) idMap.set(idNs + ':' + rs(), first + x)
          last = first + size - 1
        }
      }
      registries.set(regNs + ':' + regPath, idMap)
    }
  }
  return registries
}

/* ───────────── state 表（从服务端导出）───────────── */

/** 只凭名字猜是不是实心方块；猜错的后果是走过去/掉下去，保守一点 */
function guessBoundingBox (name) {
  if (/(^|:)(air|cave_air|void_air|water|lava|fire|soul_fire)$/.test(name)) return 'empty'
  if (/water|lava|torch|flower|sapling|plant|grass|fern|carpet|snow_layer|rail|lever|button|pressure_plate|tripwire|redstone_wire|scaffolding|vine|lily_pad|kelp|seagrass|sugar_cane|bamboo|web|crop|stem|wheat|carrots|potatoes|beetroots|nether_wart|frogspawn|root|mushroom|lichen|moss|azalea_leaves|bush|bud$/.test(name)) return 'empty'
  return 'block'
}

function makeBlockData (name) {
  const short = name.includes(':') ? name.split(':')[1] : name
  const box = guessBoundingBox(name)
  return {
    id: -1,
    name,
    displayName: short,
    stateId: -1,
    minStateId: -1,
    maxStateId: -1,
    defaultState: -1,
    hardness: 1,
    boundingBox: box,
    // prismarine-physics 要遍历这个；空数组 = 无碰撞，全方块 = 标准碰撞箱
    shapes: box === 'empty' ? [] : [[0, 0, 0, 1, 1, 1]],
    type: 0,
    material: 'unknown',
    diggable: !/^(minecraft:)?(air|cave_air|void_air|bedrock|barrier|command_block|structure_void|water|lava|fire|soul_fire)$/.test(name),
  }
}

/**
 * 解析服务端导出的 state 表（每行 "stateId|namespace:block"）。
 * 返回 { states: Map<stateId, name>, names: Set<string>, max, count }
 */
let _stateTableCache = null
export function loadStateTable (path = STATE_TABLE_PATH) {
  if (_stateTableCache && _stateTableCache.path === path) return _stateTableCache.table
  if (!existsSync(path)) return null
  const raw = readFileSync(path, 'utf8')
  const states = new Map()
  const names = new Set()
  let max = -1
  let count = 0
  let pos = 0
  const len = raw.length
  while (pos < len) {
    let nl = raw.indexOf('\n', pos)
    if (nl < 0) nl = len
    const line = raw.slice(pos, nl)
    pos = nl + 1
    if (!line) continue
    const bar = line.indexOf('|')
    if (bar <= 0) continue
    const id = Number(line.slice(0, bar))
    if (!Number.isFinite(id) || id < 0) continue
    const name = line.slice(bar + 1)
    states.set(id, name)
    names.add(name)
    if (id > max) max = id
    count++
  }
  const table = { states, names, max, count }
  _stateTableCache = { path, table }
  return table
}

/**
 * 把导出的 state 表整体替换进 registry。
 *
 * 🔴 不能给所有方块都建占位对象：原版方块在 minecraft-data 里带着
 *    type（material 数字）/ shapes（碰撞箱）/ hardness，这些是 mc_map、
 *    mc_height、findBlock、prismarine-physics 依赖的东西。全换成占位会导致：
 *      · blocksByName 里 id=-1 → mc_scan/mc_dig 找不到任何方块
 *      · type=0（空气）→ mc_map 全灰、mc_height 全空
 *      · shapes 统一整块 → 走路往天上爬
 *    所以：原版方块复用旧 registry 里的对象，只有模组方块才新建。
 */
export function installStateTable (bot, table) {
  if (!table || !bot?.registry) return { states: 0, blocks: 0 }
  const reg = bot.registry
  const old = reg.blocksByStateId || {}

  // 旧表里 name → 原版 state 对象（带完整 type/shapes/hardness）
  const byName = new Map()
  const keys = Object.keys(old)
  for (let i = 0; i < keys.length; i++) {
    const b = old[keys[i]]
    if (b && b.name && !byName.has(b.name)) byName.set(b.name, b)
  }

  const byId = {}
  let reused = 0
  let created = 0
  for (const [id, name] of table.states) {
    // 原版：复用旧 state 对象（带 type/shapes/hardness）
    // 模组：复用 injectRegistries 建的对象（带正确 registry id）
    let b = byName.get(name) || reg.blocksByName?.[name]
    if (!b) {
      b = makeBlockData(name)
      created++
    } else {
      reused++
    }
    // 原版 state 对象可能没带 block id，补上（mineflayer 的 dig/findBlock 会用）
    if (b.id === undefined || b.id === -1 || b.id === null) {
      const known = reg.blocksByName?.[name]
      if (known && typeof known.id === 'number') b.id = known.id
    }
    byId[id] = b
  }
  reg.blocksByStateId = byId
  return { states: table.count, blocks: table.names.size, reused, created, max: table.max }
}

/* ───────────── 注入 ───────────── */

function guessEntityType (name) {
  if (/boat|minecart|firework|tnt|projectile|arrow|trident|snowball|egg|potion|lootr|item/.test(name)) return 'object'
  if (/enderman|zombie|skeleton|creeper|spider|pig|sheep|cow|chicken|villager|guard|glare|moobloom|iceologer|duck|deer|bear|wolf|cat|fish|axolotl|bee|golem|boar|mimic|slime|widow|wisp/.test(name)) return 'mob'
  return 'other'
}

/**
 * 注入一张注册表。可重复调用（已有的跳过）。
 * @returns {{entities:number, items:number, blocks:number}}
 */
export function injectRegistries (bot, registries) {
  const r = bot?.registry
  if (!r) return { entities: 0, items: 0, blocks: 0 }
  let entities = 0
  let items = 0
  let blocks = 0

  const ents = registries.get('minecraft:entity_type')
  if (ents) {
    for (const [name, id] of ents) {
      if (r.entities?.[id]) continue
      const short = name.split(':')[1]
      const data = {
        id,
        internalId: id,
        name,
        displayName: short,
        type: guessEntityType(name),
        category: 'unknown',
        height: 1.8,
        width: 0.6,
        metadataKeys: [],
      }
      if (r.entities) r.entities[id] = data
      if (Array.isArray(r.entitiesArray)) r.entitiesArray.push(data)
      if (r.entitiesByName) r.entitiesByName[name] = data
      entities++
    }
  }

  const its = registries.get('minecraft:item')
  if (its) {
    for (const [name, id] of its) {
      if (r.itemsByName?.[name]) continue
      const short = name.split(':')[1]
      const data = { id, name, displayName: short, stackSize: 64 }
      if (Array.isArray(r.itemsArray)) r.itemsArray.push(data)
      if (r.itemsByName) r.itemsByName[name] = data
      // prismarine-item 用 registry.items[type] 查名字，不补这条物品就显示 unknown
      if (r.items) r.items[id] = data
      items++
    }
  }

  const blks = registries.get('minecraft:block')
  if (blks) {
    for (const [name, id] of blks) {
      if (r.blocksByName?.[name]) continue
      const data = makeBlockData(name)
      data.id = id
      if (r.blocksByName) r.blocksByName[name] = data
      if (Array.isArray(r.blocksArray)) r.blocksArray.push(data)
      if (r.blocks) r.blocks[id] = data
      blocks++
    }
  }
  return { entities, items, blocks }
}

/** 把未知 state id 兜底成占位块，避免 blockAt 返回 undefined 让机器人穿模 */
export function installStateFallback (bot, maxStateId = 120000) {
  const byState = bot?.registry?.blocksByStateId
  if (!byState) return 0
  const placeholder = {
    id: -1,
    name: 'unknown:modded_block',
    displayName: 'unknown modded block',
    type: 0,
    stateId: -1,
    hardness: 1,
    boundingBox: 'block',
    diggable: false,
  }
  let filled = 0
  if (Array.isArray(byState)) {
    for (let i = 0; i < maxStateId; i++) {
      if (!byState[i]) { byState[i] = { ...placeholder, stateId: i }; filled++ }
    }
  } else {
    for (let i = 0; i < maxStateId; i++) {
      if (!byState[i]) { byState[i] = { ...placeholder, stateId: i }; filled++ }
    }
  }
  return filled
}

/* ───────────── 挂载 ───────────── */

/**
 * 挂到 bot 上：自动收集分片、解析、注入。
 * @param {object} bot
 * @param {{log?:Function, onReady?:Function}} [opts]
 */
export function attachModRegistry (bot, opts = {}) {
  const log = opts.log || (() => {})
  const client = bot?._client
  if (!client) return { detach () {} }
  const chunks = []
  let done = false

  const onPacket = (data, meta) => {
    if (!meta || meta.name !== 'custom_payload' || data.channel !== CHANNEL) return
    if (done) return
    if (!data.data || data.data.length === 0) {
      done = true
      try {
        const registries = parseRegistrySync(Buffer.concat(chunks))
        const added = injectRegistries(bot, registries)
        // 优先用服务端导出的完整 state 表；没有就兜底未知 state
        let stateInfo = null
        const table = loadStateTable()
        if (table && table.count > 0) {
          stateInfo = installStateTable(bot, table)
          log(`模组注册表：实体 +${added.entities}，物品 +${added.items}，方块 +${added.blocks}；state 表 ${stateInfo.states} 条（${stateInfo.blocks} 个方块，最大 id ${stateInfo.max}）`)
        } else {
          const filled = installStateFallback(bot)
          log(`模组注册表：实体 +${added.entities}，物品 +${added.items}，方块 +${added.blocks}；没有 state 表，未知 state 兜底 ${filled}`)
        }
        const out = {
          capturedAt: new Date().toISOString(),
          version: bot.version,
          registries: {},
        }
        for (const [k, m] of registries) out.registries[k] = Object.fromEntries(m)
        try { writeFileSync(SNAPSHOT_PATH, JSON.stringify(out)) } catch { /* 写盘失败不影响运行 */ }
        try { opts.onReady?.({ ...added, states: stateInfo?.states ?? 0, registries }) } catch { /* ignore */ }
      } catch (e) {
        log('模组注册表解析失败：' + e.message)
      }
      return
    }
    chunks.push(data.data)
  }

  client.on('packet', onPacket)
  return {
    detach () { try { client.off('packet', onPacket) } catch { /* ignore */ } },
    get done () { return done },
  }
}

export { parseRegistrySync }
